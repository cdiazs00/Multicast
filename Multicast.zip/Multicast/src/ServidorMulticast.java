import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.Random;

public class ServidorMulticast {
    public static void main(String[] args) {
        try {
            InetAddress grup = InetAddress.getByName("224.1.1.1");
            int port = 5007;

            String[] paraules = {"hola", "mon", "java", "programacio", "multicast"};

            MulticastSocket socket = new MulticastSocket(port);
            socket.joinGroup(grup);

            while (true) {
                String paraula = paraules[new Random().nextInt(paraules.length)];
                byte[] data = paraula.getBytes();
                DatagramPacket packet = new DatagramPacket(data, data.length, grup, port);
                socket.send(packet);
                Thread.sleep(2000);
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}