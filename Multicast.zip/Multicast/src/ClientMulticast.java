import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;

public class ClientMulticast {
    public static void main(String[] args) {
        try {
            InetAddress grup = InetAddress.getByName("224.1.1.1");
            int port = 5007;

            MulticastSocket socket = new MulticastSocket(port);
            socket.joinGroup(grup);

            while (true) {
                byte[] buffer = new byte[1024];
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                socket.receive(packet);
                String paraula = new String(packet.getData(), 0, packet.getLength());
                System.out.println(paraula + " ha sortit " + contarAparicions(paraula) + " vegades des de que t'has connectat");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static int contarAparicions(String palabra) {
        return palabra.length();
    }
}